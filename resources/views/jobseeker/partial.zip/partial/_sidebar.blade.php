

<div class="well">
  
                    
                    <nav class="">
                       <ul>
                          
                          <li>
                              <a href="{{-- {{url('jobseeker/profile/'.Auth::guard('jobseeker')->user()->id)}} --}}" class="active">
                             Manage Profile
                             </a>
                          </li>
                          <li>
                             <a href="{{url('jobseeker/managejobs')}}" class="">
                              Manage Jobs
                             </a>
                          </li>
                          <li>
                             <a href="">

                             Edit Resume
                             </a>
                          </li>
                          <li>
                             <a href="">  Upload Resume

                             </a>
                          </li>
                          <li>
                             <a href=""></i> Email Resume
                             </a>
                          </li>
                          <li>
                             <a href="">Delete Resume
                             </a>
                          </li>
                          <li class="title">My Activities</li>
                          <li>
                          <a href="">Online Application</a>
						  </li>
                          <li>
						  <a href="">
                          
                          Emailed Resume</a>
						  </li>
                          <li><a href="">
                          Shortlisted Job</a></li>
                          <li><a href="">
                          Following Employer</a></li>
                          
                          
                          
                          <li class="title">Employer Activities</li>
                          <li>
                             <a href="">Employer Viewed Resume
                             </a>
                          </li>
							
                          <li>
                             <a href=""> Employer Invitation
                             </a>
                          </li>
                        
   							

                          
                          <li class="title">Personalization</li>
                          <li>
                             <a href=""> Job Agent
                             </a>
                          </li>
                         
                          <li>
                             <a href=""> Block Employer
                             </a>
                          </li>
                           <li>
                             <a href=""> Email Notification
                             </a>
                          </li>
                           
                          <li>
                             <a href=""> Trainings
                             </a>
                          </li>
                             
                        
                         
                          <li>
                             <a href=""> Help Videos
                             </a>
                          </li>
                           <li>
                             <a href=""> Change Password
                             </a>
                          </li>
                          <li>
                             <a href="" class="">
                            Sign Out
                             </a>
                          </li>
                           
                    
                        
                       </ul>
                    </nav>
                 
</div>

   
  